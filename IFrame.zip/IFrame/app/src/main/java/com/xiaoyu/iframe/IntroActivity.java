package com.xiaoyu.iframe;

import android.app.Activity;
import android.os.Bundle;

import com.xiaoyu.iframe.databinding.ActivityIntroBinding;

public class IntroActivity extends Activity {

    private ActivityIntroBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityIntroBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
    }
}