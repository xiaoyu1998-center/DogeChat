package com.xiaoyu.iframe;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.PlaybackParams;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.TypedValue;
import android.view.View;

import androidx.annotation.RequiresApi;

import com.xiaoyu.iframe.databinding.ActivityCalculatorBinding;

public class CalculatorActivity extends Activity {

    private ActivityCalculatorBinding binding;

    // Calculation
    private final char ADDITION = '+';
    private final char SUBTRACTION = '-';
    private final char MULTIPLICATION = '*';
    private final char DIVISION = '/';
    private final char EQU = '=';
    private final char EXTRA = '@';
    private final char MODULUS = '%';
    private final char SIGN = '#';
    private char ACTION;
    private double val1 = Double.NaN;
    private double val2;

    // Sound SFX
    private MediaPlayer click;
    private MediaPlayer finish;
    private final static int MIN_VOLUME = 100;
    private final static int MAX_VOLUME = 100;
    private final static float SPEED = 0.75f;

    // Delay
    private Handler handler;
    private final static int DELAY_TIME = 500;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCalculatorBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        init();
        setListeners();
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void init() {
        handler = new Handler();

        click = MediaPlayer.create(getApplicationContext(), R.raw.click_sfx);
        finish = MediaPlayer.create(getApplicationContext(), R.raw.finish_sfx);

        final float volume = (float) (1 - (Math.log(MAX_VOLUME - MIN_VOLUME) / Math.log(MAX_VOLUME)));
        click.setVolume(volume, volume);
        finish.setVolume(volume, volume);

        click.setPlaybackParams(click.getPlaybackParams().setSpeed(SPEED));
        finish.setPlaybackParams(finish.getPlaybackParams().setSpeed(SPEED));
    }

    private void setListeners() {
        binding.button1.setOnClickListener(view -> {
            ifErrorOnOutput();
            exceedLength();
            binding.input.setText(binding.input.getText().toString() + "1");

            click.start();
        });

        binding.button2.setOnClickListener(view -> {
            ifErrorOnOutput();
            exceedLength();
            binding.input.setText(binding.input.getText().toString() + "2");

            click.start();
        });

        binding.button3.setOnClickListener(view -> {
            ifErrorOnOutput();
            exceedLength();
            binding.input.setText(binding.input.getText().toString() + "3");

            click.start();
        });

        binding.button4.setOnClickListener(view -> {
            ifErrorOnOutput();
            exceedLength();
            binding.input.setText(binding.input.getText().toString() + "4");

            click.start();
        });

        binding.button5.setOnClickListener(view -> {
            ifErrorOnOutput();
            exceedLength();
            binding.input.setText(binding.input.getText().toString() + "5");

            click.start();
        });

        binding.button6.setOnClickListener(view -> {
            ifErrorOnOutput();
            exceedLength();
            binding.input.setText(binding.input.getText().toString() + "6");

            click.start();
        });

        binding.button7.setOnClickListener(view -> {
            ifErrorOnOutput();
            exceedLength();
            binding.input.setText(binding.input.getText().toString() + "7");

            click.start();
        });

        binding.button8.setOnClickListener(view -> {
            ifErrorOnOutput();
            exceedLength();
            binding.input.setText(binding.input.getText().toString() + "8");

            click.start();
        });

        binding.button9.setOnClickListener(view -> {
            ifErrorOnOutput();
            exceedLength();
            binding.input.setText(binding.input.getText().toString() + "9");

            click.start();
        });

        binding.button0.setOnClickListener(view -> {
            ifErrorOnOutput();
            exceedLength();
            binding.input.setText(binding.input.getText().toString() + "0");

            click.start();
        });

        binding.buttonDot.setOnClickListener(view -> {
            exceedLength();
            binding.input.setText(binding.input.getText().toString() + ".");

            click.start();
        });

        binding.buttonPara1.setOnClickListener(view -> {
            if (binding.input.getText().length() > 0) {
                ACTION = MODULUS;
                operation();
                if (!ifReallyDecimal()) {
                    binding.output.setText(val1 + "%");
                } else {
                    binding.output.setText((int) val1 + "%");
                }
                binding.input.setText(null);
            } else {
                binding.output.setText("Error");
            }

            click.start();
        });

        binding.buttonAdd.setOnClickListener(view -> {
            if (binding.input.getText().length() > 0) {
                ACTION = ADDITION;
                operation();
                if (!ifReallyDecimal()) {
                    binding.output.setText(val1 + "+");
                } else {
                    binding.output.setText((int) val1 + "+");
                }
                binding.input.setText(null);
            } else {
                binding.output.setText("Error");
            }

            click.start();
        });

        binding.buttonSub.setOnClickListener(view -> {
            if (binding.input.getText().length() > 0) {
                ACTION = SUBTRACTION;
                operation();
                if (binding.input.getText().length() > 0)
                    if (!ifReallyDecimal()) {
                        binding.output.setText(val1 + "-");
                    } else {
                        binding.output.setText((int) val1 + "-");
                    }
                binding.input.setText(null);
            } else {
                binding.output.setText("Error");
            }

            click.start();
        });

        binding.buttonMulti.setOnClickListener(view -> {
            if (binding.input.getText().length() > 0) {
                ACTION = MULTIPLICATION;
                operation();
                if (!ifReallyDecimal()) {
                    binding.output.setText(val1 + "×");
                } else {
                    binding.output.setText((int) val1 + "×");
                }
                binding.input.setText(null);
            } else {
                binding.output.setText("Error");
            }

            click.start();
        });

        binding.buttonDivide.setOnClickListener(view -> {
            if (binding.input.getText().length() > 0) {
                ACTION = DIVISION;
                operation();
                if (ifReallyDecimal()) {
                    binding.output.setText((int) val1 + "/");
                } else {
                    binding.output.setText(val1 + "/");
                }
                binding.input.setText(null);
            } else {
                binding.output.setText("Error");
            }

            click.start();
        });

        binding.buttonPara2.setOnClickListener(view -> {
            if (!binding.output.getText().toString().isEmpty() || !binding.input.getText().toString().isEmpty()) {
                val1 = Double.parseDouble(binding.input.getText().toString());
                ACTION = EXTRA;
                binding.output.setText("-" + binding.input.getText().toString());
                binding.input.setText("");
            } else {
                binding.output.setText("Error");
            }

            click.start();
        });

        binding.buttonSign.setOnClickListener(view -> {

            ACTION = SIGN;
            binding.input.setText("#");

            click.start();
        });

        binding.buttonEqual.setOnClickListener(view -> {
            if (binding.input.getText().length() > 0) {
                operation();
                ACTION = EQU;

                if (binding.input.getText().toString().charAt(0) != '#') {
                    if (!ifReallyDecimal()) {
                        binding.output.setText(/*t2.getText().toString() + String.valueOf(val2) + "=" + */String.valueOf(val1));
                    } else {
                        binding.output.setText(/*t2.getText().toString() + String.valueOf(val2) + "=" + */String.valueOf((int) val1));
                    }
                }
                binding.input.setText(null);
            } else {
                binding.output.setText("Error");
            }

            finish.start();
        });

        binding.buttonClear.setOnClickListener(view -> {
            clearCalculation();
            click.start();
        });

        // Empty text views on long click.
        binding.buttonClear.setOnLongClickListener(view -> {
            val1 = Double.NaN;
            val2 = Double.NaN;
            binding.input.setText("");
            binding.output.setText("");
            return true;
        });
    }

    private void clearCalculation() {
        if (binding.input.getText().length() > 0) {
            CharSequence name = binding.input.getText().toString();
            binding.input.setText(name.subSequence(0, name.length() - 1));
        } else {
            val1 = Double.NaN;
            val2 = Double.NaN;
            binding.input.setText("");
            binding.output.setText("");
        }
    }

    private void operation() {
        if (binding.input.getText().toString().charAt(0) == '#') {
            if (binding.input.getText().toString().equals("#123.456")) {
                binding.output.setText("Success...");

                handler.postDelayed(() -> {
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                }, DELAY_TIME);

            } else {
                binding.output.setText("Try Again...");
            }
        } else if (binding.input.getText().toString().charAt(0) != '#') {
            if (!Double.isNaN(val1)) {
                if (binding.output.getText().toString().charAt(0) == '-') {
                    val1 = (-1) * val1;
                }
                val2 = Double.parseDouble(binding.input.getText().toString());

                switch (ACTION) {
                    case ADDITION:
                        val1 = val1 + val2;
                        break;
                    case SUBTRACTION:
                        val1 = val1 - val2;
                        break;
                    case MULTIPLICATION:
                        val1 = val1 * val2;
                        break;
                    case DIVISION:
                        val1 = val1 / val2;
                        break;
                    case EXTRA:
                        val1 = (-1) * val1;
                        break;
                    case MODULUS:
                        val1 = val1 % val2;
                        break;
                    case SIGN:

                        break;
                    case EQU:
                        break;
                }
            } else {
                val1 = Double.parseDouble(binding.input.getText().toString());
            }
        }
    }

    // Remove error message that is already written there.
    private void ifErrorOnOutput() {
        if (binding.output.getText().toString().equals("Error")) {
            binding.output.setText("");

            clearCalculation();
        }
    }

    // Whether value if a double or not
    private boolean ifReallyDecimal() {
        return val1 == (int) val1;
    }

    private void noOperation() {
        String inputExpression = binding.output.getText().toString();
        if (!inputExpression.isEmpty() && !inputExpression.equals("Error")) {
            if (inputExpression.contains("-")) {
                inputExpression = inputExpression.replace("-", "");
                binding.output.setText("");
                val1 = Double.parseDouble(inputExpression);
            }
            if (inputExpression.contains("+")) {
                inputExpression = inputExpression.replace("+", "");
                binding.output.setText("");
                val1 = Double.parseDouble(inputExpression);
            }
            if (inputExpression.contains("/")) {
                inputExpression = inputExpression.replace("/", "");
                binding.output.setText("");
                val1 = Double.parseDouble(inputExpression);
            }
            if (inputExpression.contains("%")) {
                inputExpression = inputExpression.replace("%", "");
                binding.output.setText("");
                val1 = Double.parseDouble(inputExpression);
            }
            if (inputExpression.contains("×")) {
                inputExpression = inputExpression.replace("×", "");
                binding.output.setText("");
                val1 = Double.parseDouble(inputExpression);
            }
        }
    }

    // Make text small if too many digits.
    private void exceedLength() {
        if (binding.input.getText().toString().length() > 10) {
            binding.input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        }
    }
}